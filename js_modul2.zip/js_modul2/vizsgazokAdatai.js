//Vizsgált objektum:
const vizsgazokAdatai = [{
    nev: "Koaxk Ábel",
    htmlVizsgaresz: 15,
    bootstrapVizsgaresz: 15,
    javaScriptVizsgaresz: 20,
    typeScriptVizsgaresz: 15,
    angularVizsgaresz: 10,
    serverVizsgaresz:15
},
{
    nev: "Meg Győző",
    htmlVizsgaresz: 15,
    bootstrapVizsgaresz: 15,
    javaScriptVizsgaresz: 20,
    typeScriptVizsgaresz: 20,
    angularVizsgaresz: 15,
    serverVizsgaresz:15
},
{
    nev: "Fejet Lenke",
    htmlVizsgaresz: 15,
    bootstrapVizsgaresz: 15,
    javaScriptVizsgaresz: 5,
    typeScriptVizsgaresz: 5,
    angularVizsgaresz: 5,
    serverVizsgaresz:5
},
{
    nev: "Vak Cina",
    htmlVizsgaresz: 15,
    bootstrapVizsgaresz: 15,
    javaScriptVizsgaresz: 20,
    typeScriptVizsgaresz: 20,
    angularVizsgaresz: 10,
    serverVizsgaresz:10
},
{
    nev: "Akciós Áron",
    htmlVizsgaresz: 10,
    bootstrapVizsgaresz: 10,
    javaScriptVizsgaresz: 10,
    typeScriptVizsgaresz: 10,
    angularVizsgaresz: 10,
    serverVizsgaresz:10
},
{
    nev: "Boro Zoltán",
    htmlVizsgaresz: 15,
    bootstrapVizsgaresz: 15,
    javaScriptVizsgaresz: 15,
    typeScriptVizsgaresz: 15,
    angularVizsgaresz: 10,
    serverVizsgaresz:10
},
{
    nev: "Eszet Lenke",
    htmlVizsgaresz: 5,
    bootstrapVizsgaresz: 5,
    javaScriptVizsgaresz: 5,
    typeScriptVizsgaresz: 5,
    angularVizsgaresz: 5,
    serverVizsgaresz:5
},
{
    nev: "Békés Csaba",
    htmlVizsgaresz: 15,
    bootstrapVizsgaresz: 15,
    javaScriptVizsgaresz: 20,
    typeScriptVizsgaresz: 20,
    angularVizsgaresz: 15,
    serverVizsgaresz:15
},
];