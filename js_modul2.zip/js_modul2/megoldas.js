//Ide illessze be a JavasScript kódot a teszteléshez
//1.feladat:
function OsztokSzama(vizsgaltSzam){
	let osztokSzama=0;
   	 	for (let i = 0; i <= vizsgaltSzam; i++) {
  	  	if (vizsgaltSzam % i == 0)
        	osztokSzama += 1;
     }
     return osztokSzama;
     }
function OsztokSzamaKiir(VizsgalandoSzam){
	document.write(`A ${VizsgalandoSzam} osztóinak száma: ${feladat}<br>`);
}
feladat=OsztokSzama(12)
OsztokSzamaKiir(12);
feladat=OsztokSzama(6)
OsztokSzamaKiir(6);
feladat=OsztokSzama(4)
OsztokSzamaKiir(4);
//2. feladat
function ParatlanLista(vizsgalt_tomb) {
    let darab = [];
    for (let i = 0; i < vizsgalt_tomb.length; i++) {
        if (vizsgalt_tomb[i] % 2 == 1) {
           darab.push(vizsgalt_tomb[i]);
        }       
    }
    return darab;
}
function EredmenyKi(szoveg, eredmeny) {
	console.log(szoveg + eredmeny);
}

feladat1= ParatlanLista([42,21,69,33,66]);
EredmenyKi("A tömbben lévő páros számok listája:", feladat1);
feladat2=ParatlanLista([1,2,3,4,5]);
EredmenyKi("A tömbben lévő páros számok listája:", feladat2);
feladat3= ParatlanLista([4,6,3,5]);
EredmenyKi("A tömbben lévő páros számok listája:", feladat3);
/*
//megoldás3.
function VizsgaEredmeny(vizsgaltTomb, nev){
	let OsszPontSzam=0;
    for(let i=0; i<nev[i].length; i++){
    	OsszPontSzam=OsszPontSzam+(vizsgaltTomb[i].htmlVizsgaresz+vizsgaltTomb[i].bootstrapVizsgaresz+vizsgaltTomb[i].javaScriptVizsgaresz+vizsgaltTomb[i].typeScriptVizsgaresz+vizsgaltTomb[i].angularVizsgaresz+vizsgaltTomb[i].serverVizsgaresz);
    }
    return OsszPontSzam;
}
function VizsgaEredmenyKiir(Osszesen, neve){
	document.write(`A ${neve} vizsga eredménye: ${Osszesen}`);
}
eredmeny=VizsgaEredmeny(vizsgazokAdatai,"Eszet Lenke")
VizsgaEredmenyKiir(eredmeny, "Eszet Lenke");*/


