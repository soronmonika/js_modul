//Ide illessze be a JavasScript kódot a teszteléshez
//1.feladat:
function OsztokSzama(vizsgaltSzam){
	let osztokSzama=0;
   	 	for (let i = 0; i <= vizsgaltSzam; i++) {
  	  	if (vizsgaltSzam % i == 0)
        	osztokSzama += 1;
     }
     return osztokSzama;
     }
function OsztokSzamaKiir(VizsgalandoSzam){
	document.write(`A ${VizsgalandoSzam} osztóinak száma: ${feladat}<br>`);
}
feladat=OsztokSzama(12)
OsztokSzamaKiir(12);
feladat=OsztokSzama(6)
OsztokSzamaKiir(6);
feladat=OsztokSzama(4)
OsztokSzamaKiir(4);
//2. feladat
function ParatlanLista(vizsgalt_tomb) {
    let darab = [];
    for (let i = 0; i < vizsgalt_tomb.length; i++) {
        if (vizsgalt_tomb[i] % 2 == 1) {
           darab.push(vizsgalt_tomb[i]);
        }       
    }
    return darab;
}
function EredmenyKi(szoveg, eredmeny) {
	console.log(szoveg + eredmeny);
}

feladat1= ParatlanLista([42,21,69,33,66]);
EredmenyKi("A tömbben lévő páros számok listája:", feladat1);
feladat2=ParatlanLista([1,2,3,4,5]);
EredmenyKi("A tömbben lévő páros számok listája:", feladat2);
feladat3= ParatlanLista([4,6,3,5]);
EredmenyKi("A tömbben lévő páros számok listája:", feladat3);

//3.feladat
function VizsgaEredmeny(vizsgaltTomb, nev) {
    let vizsgaEredmeny = 0;
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].nev==nev)
         vizsgaEredmeny+=vizsgaltTomb[i].htmlVizsgaresz+vizsgaltTomb[i].bootstrapVizsgaresz+vizsgaltTomb[i].javaScriptVizsgaresz+vizsgaltTomb[i].typeScriptVizsgaresz+vizsgaltTomb[i].angularVizsgaresz+vizsgaltTomb[i].serverVizsgaresz;

    }
    return vizsgaEredmeny;
}

function VizsgaEredmenyKiir(eredmeny, neve) {
    document.write(`A(z) ${neve}-nak az összes pontszáma: ${eredmeny}<br>`);
}
feladat5 = VizsgaEredmeny(vizsgazokAdatai, "Eszet Lenke")
VizsgaEredmenyKiir(feladat5 , "Eszet Lenke");
feladat4 = VizsgaEredmeny(vizsgazokAdatai, "Akciós Áron")
VizsgaEredmenyKiir(feladat4 , "Akciós Áron");
feladat3 = VizsgaEredmeny(vizsgazokAdatai, "Meg Győző")
VizsgaEredmenyKiir(feladat3 , "Meg Győzőn");


